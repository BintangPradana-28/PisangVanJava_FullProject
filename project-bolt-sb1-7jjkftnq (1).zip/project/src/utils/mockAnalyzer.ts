// Mock AI analyzer simulating Random Forest + TF-IDF

export interface AnalysisResult {
  label: 'toxic' | 'non-toxic';
  confidence: number;
  riskLevel: 'Low' | 'Medium' | 'High' | 'Critical';
  action: string;
  toxicityScore: number;
  categories: { name: string; score: number }[];
}

const toxicPatterns = [
  'bodoh', 'anjing', 'bangsat', 'brengsek', 'goblok', 'tolol',
  'idiot', 'stupid', 'hate', 'kill', 'die', 'racist', 'babi',
  'kafir', 'sial', 'tai', 'fuck', 'damn', 'crap', 'burn',
  'ugly', 'trash', 'garbage', 'disgusting', 'loser', 'worthless',
];

const nonToxicPatterns = [
  'bagus', 'baik', 'indah', 'senang', 'suka', 'terima kasih',
  'good', 'great', 'excellent', 'nice', 'love', 'amazing',
  'wonderful', 'beautiful', 'thanks', 'helpful', 'awesome',
];

export function analyzeComment(text: string): AnalysisResult {
  const lower = text.toLowerCase();

  let toxicScore = 0;
  let nonToxicScore = 0;

  toxicPatterns.forEach(p => { if (lower.includes(p)) toxicScore += 25; });
  nonToxicPatterns.forEach(p => { if (lower.includes(p)) nonToxicScore += 15; });

  // Add some variance based on text length and exclamation marks
  const exclaims = (text.match(/!/g) || []).length;
  const capsRatio = (text.match(/[A-Z]/g) || []).length / Math.max(text.length, 1);

  toxicScore += exclaims * 5 + capsRatio * 30;

  // Normalize
  const total = toxicScore + nonToxicScore + 20;
  const rawToxicProb = (toxicScore + 10) / total;

  // Add controlled randomness for demo purposes
  const noise = (Math.random() - 0.5) * 0.1;
  const toxicProb = Math.max(0.05, Math.min(0.97, rawToxicProb + noise));

  const isToxic = toxicProb > 0.45;
  const confidence = Math.round(isToxic ? toxicProb * 100 : (1 - toxicProb) * 100);

  let riskLevel: AnalysisResult['riskLevel'];
  let action: string;

  if (!isToxic) {
    riskLevel = 'Low';
    action = 'No action needed — content is safe to publish';
  } else if (confidence < 70) {
    riskLevel = 'Medium';
    action = 'Flag for human review before publishing';
  } else if (confidence < 85) {
    riskLevel = 'High';
    action = 'Withhold content and send warning to user';
  } else {
    riskLevel = 'Critical';
    action = 'Immediately remove content and escalate to moderator';
  }

  return {
    label: isToxic ? 'toxic' : 'non-toxic',
    confidence,
    riskLevel,
    action,
    toxicityScore: Math.round(toxicProb * 100),
    categories: [
      { name: 'Hate Speech', score: Math.round(toxicProb * 85 + Math.random() * 10) },
      { name: 'Harassment', score: Math.round(toxicProb * 70 + Math.random() * 15) },
      { name: 'Offensive', score: Math.round(toxicProb * 90 + Math.random() * 8) },
      { name: 'Spam', score: Math.round(Math.random() * 30) },
    ],
  };
}
