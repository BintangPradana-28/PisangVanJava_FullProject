import { BarChart3, TrendingUp, Database, Target, CheckCircle2, AlertCircle } from 'lucide-react';
import { useEffect, useState } from 'react';

const METRICS = {
  totalDataset: 10000,
  training: 8000,
  testing: 2000,
  accuracy: 94.2,
  precision: 93.8,
  recall: 92.5,
  f1Score: 93.1,
  toxicCount: 4200,
  nonToxicCount: 5800,
};

const CONFUSION = {
  tp: 1890, fp: 140,
  fn: 160, tn: 2610,
};

const CLASS_REPORT = [
  { class: 'Non-Toxic', precision: 95.1, recall: 94.3, f1: 94.7, support: 2750 },
  { class: 'Toxic', precision: 93.1, recall: 92.2, f1: 92.6, support: 1850 },
];

function useCountUp(target: number, duration = 1500) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    let start = 0;
    const step = target / (duration / 16);
    const interval = setInterval(() => {
      start += step;
      if (start >= target) {
        setValue(target);
        clearInterval(interval);
      } else {
        setValue(Math.floor(start));
      }
    }, 16);
    return () => clearInterval(interval);
  }, [target, duration]);
  return value;
}

function MetricWidget({ label, value, unit = '', color, icon: Icon, description }: {
  label: string; value: number; unit?: string; color: string; icon: React.ElementType; description: string;
}) {
  const display = useCountUp(value * (unit === '%' ? 10 : 1));
  const formatted = unit === '%' ? (display / 10).toFixed(1) : display.toLocaleString();
  return (
    <div className="metric-card">
      <div className="flex items-start justify-between mb-3">
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${color}`}>
          <Icon className="w-5 h-5" />
        </div>
        <span className="text-xs text-gray-400 dark:text-gray-500">{description}</span>
      </div>
      <div className="text-2xl font-bold text-gray-900 dark:text-white font-['Space_Grotesk']">
        {formatted}{unit}
      </div>
      <div className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">{label}</div>
    </div>
  );
}

function BarChartComponent() {
  const bars = [
    { label: 'Accuracy', value: 94.2, color: 'bg-blue-500' },
    { label: 'Precision', value: 93.8, color: 'bg-emerald-500' },
    { label: 'Recall', value: 92.5, color: 'bg-amber-500' },
    { label: 'F1 Score', value: 93.1, color: 'bg-purple-500' },
  ];

  const [animated, setAnimated] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setAnimated(true), 300);
    return () => clearTimeout(t);
  }, []);

  return (
    <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800 shadow-sm p-6">
      <h3 className="font-semibold text-gray-800 dark:text-white mb-1">Model Performance Metrics</h3>
      <p className="text-xs text-gray-400 mb-6">Random Forest classifier evaluation on test set</p>
      <div className="space-y-4">
        {bars.map(b => (
          <div key={b.label}>
            <div className="flex justify-between text-sm mb-1.5">
              <span className="font-medium text-gray-700 dark:text-gray-300">{b.label}</span>
              <span className="font-bold text-gray-900 dark:text-white">{b.value}%</span>
            </div>
            <div className="h-3 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden">
              <div
                className={`h-full ${b.color} rounded-full transition-all duration-1000 ease-out`}
                style={{ width: animated ? `${b.value}%` : '0%' }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function PieChart() {
  const total = METRICS.totalDataset;
  const toxicPct = METRICS.toxicCount / total;
  const nonToxicPct = METRICS.nonToxicCount / total;

  const r = 60;
  const circ = 2 * Math.PI * r;
  const toxicDash = circ * toxicPct;
  const nonToxicDash = circ * nonToxicPct;

  return (
    <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800 shadow-sm p-6">
      <h3 className="font-semibold text-gray-800 dark:text-white mb-1">Dataset Distribution</h3>
      <p className="text-xs text-gray-400 mb-4">Toxic vs Non-Toxic class balance</p>
      <div className="flex items-center justify-center gap-8">
        <svg viewBox="0 0 140 140" className="w-32 h-32">
          <circle cx="70" cy="70" r={r} fill="none" stroke="#10b981" strokeWidth="18"
            strokeDasharray={`${nonToxicDash} ${circ}`}
            transform="rotate(-90 70 70)"
          />
          <circle cx="70" cy="70" r={r} fill="none" stroke="#ef4444" strokeWidth="18"
            strokeDasharray={`${toxicDash} ${circ - toxicDash}`}
            strokeDashoffset={-nonToxicDash}
            transform="rotate(-90 70 70)"
          />
          <text x="70" y="65" textAnchor="middle" fontSize="11" fontWeight="600" className="fill-gray-700 dark:fill-gray-300">Total</text>
          <text x="70" y="80" textAnchor="middle" fontSize="14" fontWeight="700" fontFamily="Space Grotesk" className="fill-gray-900 dark:fill-white">
            {(total / 1000).toFixed(0)}K
          </text>
        </svg>
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-3 h-3 rounded-full bg-emerald-500 flex-shrink-0" />
            <div>
              <div className="text-sm font-semibold text-gray-800 dark:text-gray-200">Non-Toxic</div>
              <div className="text-xs text-gray-400">{METRICS.nonToxicCount.toLocaleString()} ({(nonToxicPct * 100).toFixed(0)}%)</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-3 h-3 rounded-full bg-red-500 flex-shrink-0" />
            <div>
              <div className="text-sm font-semibold text-gray-800 dark:text-gray-200">Toxic</div>
              <div className="text-xs text-gray-400">{METRICS.toxicCount.toLocaleString()} ({(toxicPct * 100).toFixed(0)}%)</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ConfusionMatrix() {
  const { tp, fp, fn, tn } = CONFUSION;
  const total = tp + fp + fn + tn;
  const cells = [
    { label: 'True Positive', value: tp, bg: 'bg-emerald-100 dark:bg-emerald-900/30', text: 'text-emerald-700 dark:text-emerald-400', border: 'border-emerald-200 dark:border-emerald-800' },
    { label: 'False Positive', value: fp, bg: 'bg-red-100 dark:bg-red-900/30', text: 'text-red-700 dark:text-red-400', border: 'border-red-200 dark:border-red-800' },
    { label: 'False Negative', value: fn, bg: 'bg-amber-100 dark:bg-amber-900/30', text: 'text-amber-700 dark:text-amber-400', border: 'border-amber-200 dark:border-amber-800' },
    { label: 'True Negative', value: tn, bg: 'bg-blue-100 dark:bg-blue-900/30', text: 'text-blue-700 dark:text-blue-400', border: 'border-blue-200 dark:border-blue-800' },
  ];

  return (
    <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800 shadow-sm p-6">
      <h3 className="font-semibold text-gray-800 dark:text-white mb-1">Confusion Matrix</h3>
      <p className="text-xs text-gray-400 mb-4">Test set: {total.toLocaleString()} samples</p>
      <div className="grid grid-cols-2 gap-3 mb-4">
        {cells.map(c => (
          <div key={c.label} className={`${c.bg} ${c.border} border rounded-xl p-4 text-center`}>
            <div className={`text-2xl font-bold ${c.text} font-['Space_Grotesk']`}>{c.value.toLocaleString()}</div>
            <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">{c.label}</div>
            <div className={`text-xs font-medium ${c.text} mt-0.5`}>
              {((c.value / total) * 100).toFixed(1)}%
            </div>
          </div>
        ))}
      </div>
      <div className="grid grid-cols-2 gap-2 text-xs text-center">
        <div className="text-gray-400 dark:text-gray-500">Predicted: Toxic | Predicted: Non-Toxic</div>
        <div />
      </div>
    </div>
  );
}

function DatasetBreakdown() {
  const splits = [
    { label: 'Training Set', value: METRICS.training, pct: 80, color: 'bg-blue-500' },
    { label: 'Testing Set', value: METRICS.testing, pct: 20, color: 'bg-cyan-500' },
  ];

  return (
    <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800 shadow-sm p-6">
      <h3 className="font-semibold text-gray-800 dark:text-white mb-1">Dataset Split</h3>
      <p className="text-xs text-gray-400 mb-4">80/20 train-test split strategy</p>
      <div className="h-3 bg-gray-100 dark:bg-gray-700 rounded-full flex overflow-hidden mb-4">
        <div className="bg-blue-500 h-full" style={{ width: '80%' }} />
        <div className="bg-cyan-500 h-full" style={{ width: '20%' }} />
      </div>
      {splits.map(s => (
        <div key={s.label} className="flex items-center justify-between py-2.5 border-b border-gray-50 dark:border-gray-800 last:border-0">
          <div className="flex items-center gap-2.5">
            <div className={`w-2.5 h-2.5 rounded-full ${s.color}`} />
            <span className="text-sm text-gray-700 dark:text-gray-300">{s.label}</span>
          </div>
          <div className="text-right">
            <div className="text-sm font-bold text-gray-900 dark:text-white">{s.value.toLocaleString()}</div>
            <div className="text-xs text-gray-400">{s.pct}%</div>
          </div>
        </div>
      ))}
    </div>
  );
}

export default function AnalyticsPage() {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-gradient-to-br from-emerald-600 to-teal-500 rounded-xl flex items-center justify-center">
              <BarChart3 className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white font-['Space_Grotesk']">Analytics Dashboard</h1>
          </div>
          <p className="text-gray-500 dark:text-gray-400">Model performance metrics and dataset statistics</p>
        </div>

        {/* Top metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <MetricWidget label="Total Dataset" value={METRICS.totalDataset} color="bg-blue-100 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400" icon={Database} description="Samples" />
          <MetricWidget label="Training Data" value={METRICS.training} color="bg-emerald-100 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400" icon={TrendingUp} description="80% split" />
          <MetricWidget label="Testing Data" value={METRICS.testing} color="bg-cyan-100 dark:bg-cyan-900/20 text-cyan-600 dark:text-cyan-400" icon={Target} description="20% split" />
          <MetricWidget label="Model Accuracy" value={METRICS.accuracy} unit="%" color="bg-purple-100 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400" icon={CheckCircle2} description="Test set" />
        </div>

        {/* Performance metrics */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
          {[
            { label: 'Precision', value: METRICS.precision, desc: 'Positive predictive value', icon: Target, color: 'bg-emerald-100 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400' },
            { label: 'Recall', value: METRICS.recall, desc: 'True positive rate (sensitivity)', icon: TrendingUp, color: 'bg-amber-100 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400' },
            { label: 'F1 Score', value: METRICS.f1Score, desc: 'Harmonic mean of P & R', icon: CheckCircle2, color: 'bg-rose-100 dark:bg-rose-900/20 text-rose-600 dark:text-rose-400' },
          ].map(m => (
            <MetricWidget key={m.label} label={m.label} value={m.value} unit="%" color={m.color} icon={m.icon} description={m.desc} />
          ))}
        </div>

        {/* Charts grid */}
        <div className="grid lg:grid-cols-2 gap-6 mb-6">
          <BarChartComponent />
          <PieChart />
        </div>

        <div className="grid lg:grid-cols-2 gap-6 mb-6">
          <ConfusionMatrix />
          <DatasetBreakdown />
        </div>

        {/* Classification report */}
        <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800 shadow-sm p-6">
          <h3 className="font-semibold text-gray-800 dark:text-white mb-1">Classification Report</h3>
          <p className="text-xs text-gray-400 mb-4">Per-class precision, recall, and F1-score</p>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100 dark:border-gray-800">
                  {['Class', 'Precision', 'Recall', 'F1-Score', 'Support'].map(h => (
                    <th key={h} className="text-left py-3 px-4 font-semibold text-gray-500 dark:text-gray-400 text-xs uppercase tracking-wide">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {CLASS_REPORT.map((row, i) => (
                  <tr key={row.class} className={`${i % 2 === 0 ? 'bg-gray-50 dark:bg-gray-800/50' : ''} rounded-lg`}>
                    <td className="py-3 px-4 font-medium text-gray-800 dark:text-gray-200">{row.class}</td>
                    <td className="py-3 px-4 text-emerald-600 dark:text-emerald-400 font-semibold">{row.precision}%</td>
                    <td className="py-3 px-4 text-amber-600 dark:text-amber-400 font-semibold">{row.recall}%</td>
                    <td className="py-3 px-4 text-blue-600 dark:text-blue-400 font-semibold">{row.f1}%</td>
                    <td className="py-3 px-4 text-gray-600 dark:text-gray-400">{row.support.toLocaleString()}</td>
                  </tr>
                ))}
                <tr className="border-t border-gray-200 dark:border-gray-700 font-semibold">
                  <td className="py-3 px-4 text-gray-800 dark:text-gray-200">Weighted Avg</td>
                  <td className="py-3 px-4 text-gray-800 dark:text-gray-200">{METRICS.precision}%</td>
                  <td className="py-3 px-4 text-gray-800 dark:text-gray-200">{METRICS.recall}%</td>
                  <td className="py-3 px-4 text-gray-800 dark:text-gray-200">{METRICS.f1Score}%</td>
                  <td className="py-3 px-4 text-gray-800 dark:text-gray-200">{METRICS.testing.toLocaleString()}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
