import { useState } from 'react';
import { Brain, Shield, AlertTriangle, CheckCircle, ArrowRight, Zap, Database, BarChart3, ChevronRight } from 'lucide-react';
import { analyzeComment } from '../utils/mockAnalyzer';
import type { AnalysisResult } from '../utils/mockAnalyzer';

type Page = 'home' | 'moderation' | 'analytics' | 'research' | 'about';

interface HomePageProps {
  onNavigate: (page: Page) => void;
}

function ConfidenceGauge({ value, toxic }: { value: number; toxic: boolean }) {
  const r = 54;
  const circ = 2 * Math.PI * r;
  const filled = circ * (value / 100);
  const color = toxic ? '#ef4444' : '#10b981';

  return (
    <svg viewBox="0 0 120 120" className="w-28 h-28">
      <circle cx="60" cy="60" r={r} fill="none" stroke="#e5e7eb" strokeWidth="10" className="dark:stroke-gray-700" />
      <circle
        cx="60" cy="60" r={r} fill="none"
        stroke={color} strokeWidth="10"
        strokeDasharray={`${filled} ${circ}`}
        strokeLinecap="round"
        transform="rotate(-90 60 60)"
        className="confidence-ring"
      />
      <text x="60" y="56" textAnchor="middle" dominantBaseline="middle" className="fill-gray-900 dark:fill-white" fontSize="18" fontWeight="700" fontFamily="Space Grotesk">
        {value}%
      </text>
      <text x="60" y="74" textAnchor="middle" dominantBaseline="middle" fill={color} fontSize="9" fontWeight="500">
        CONFIDENCE
      </text>
    </svg>
  );
}

function ResultCard({ result }: { result: AnalysisResult }) {
  const isToxic = result.label === 'toxic';
  return (
    <div className={`mt-6 rounded-2xl border-2 p-6 animate-scale-in ${isToxic ? 'border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-950/30' : 'border-emerald-200 bg-emerald-50 dark:border-emerald-800 dark:bg-emerald-950/30'}`}>
      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-3">
            {isToxic
              ? <AlertTriangle className="w-6 h-6 text-red-500" />
              : <CheckCircle className="w-6 h-6 text-emerald-500" />
            }
            <span className={`text-lg font-bold ${isToxic ? 'text-red-600 dark:text-red-400' : 'text-emerald-600 dark:text-emerald-400'}`}>
              {isToxic ? 'Toxic Content Detected' : 'Safe Content'}
            </span>
          </div>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="bg-white dark:bg-gray-800 rounded-xl p-3">
              <div className="text-gray-500 dark:text-gray-400 text-xs mb-0.5">Classification</div>
              <div className={`font-semibold capitalize ${isToxic ? 'text-red-500' : 'text-emerald-500'}`}>{result.label}</div>
            </div>
            <div className="bg-white dark:bg-gray-800 rounded-xl p-3">
              <div className="text-gray-500 dark:text-gray-400 text-xs mb-0.5">Risk Level</div>
              <div className={`font-semibold ${isToxic ? 'text-red-500' : 'text-emerald-500'}`}>{result.riskLevel}</div>
            </div>
          </div>
          <div className="mt-3 bg-white dark:bg-gray-800 rounded-xl p-3 text-sm">
            <span className="text-gray-500 dark:text-gray-400 text-xs">Suggested Action: </span>
            <span className="font-medium text-gray-800 dark:text-gray-200">{result.action}</span>
          </div>
        </div>
        <ConfidenceGauge value={result.confidence} toxic={isToxic} />
      </div>
    </div>
  );
}

export default function HomePage({ onNavigate }: HomePageProps) {
  const [comment, setComment] = useState('');
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [loading, setLoading] = useState(false);

  const handleAnalyze = async () => {
    if (!comment.trim()) return;
    setLoading(true);
    setResult(null);
    await new Promise(r => setTimeout(r, 1200));
    setResult(analyzeComment(comment));
    setLoading(false);
  };

  const stats = [
    { icon: Database, label: 'Dataset Size', value: '10,000+', color: 'text-blue-500', bg: 'bg-blue-50 dark:bg-blue-900/20' },
    { icon: BarChart3, label: 'Model Accuracy', value: '94.2%', color: 'text-emerald-500', bg: 'bg-emerald-50 dark:bg-emerald-900/20' },
    { icon: Zap, label: 'Avg. Latency', value: '<50ms', color: 'text-amber-500', bg: 'bg-amber-50 dark:bg-amber-900/20' },
    { icon: Shield, label: 'Precision', value: '93.8%', color: 'text-purple-500', bg: 'bg-purple-50 dark:bg-purple-900/20' },
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      {/* Hero */}
      <section className="relative overflow-hidden pt-24 pb-16 lg:pt-32 lg:pb-24">
        {/* Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-600/5 via-cyan-500/5 to-transparent dark:from-blue-600/10 dark:via-cyan-500/10" />
        <div className="absolute top-20 left-10 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl" />
        <div className="absolute bottom-10 right-10 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="max-w-3xl mx-auto text-center animate-slide-in-up">
            <div className="inline-flex items-center gap-2 bg-blue-50 dark:bg-blue-900/30 border border-blue-200 dark:border-blue-800 text-blue-600 dark:text-blue-400 text-sm font-medium px-4 py-2 rounded-full mb-6">
              <Brain className="w-4 h-4" />
              Final Year Research Project — Universitas Teknologi Indonesia
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 dark:text-white leading-tight mb-6 font-['Space_Grotesk']">
              AI-Based{' '}
              <span className="text-gradient">Content Moderation</span>
              {' '}System
            </h1>
            <p className="text-lg text-gray-600 dark:text-gray-400 leading-relaxed mb-8">
              Detecting toxic Indonesian comments using <strong className="text-gray-800 dark:text-gray-200">Random Forest</strong> and <strong className="text-gray-800 dark:text-gray-200">TF-IDF</strong> feature extraction.
              A real-time web-based AI moderation platform built for academic research.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <button onClick={() => onNavigate('moderation')} className="btn-primary flex items-center justify-center gap-2">
                Try AI Moderation <ArrowRight className="w-4 h-4" />
              </button>
              <button onClick={() => onNavigate('research')} className="btn-secondary flex items-center justify-center gap-2">
                View Research <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((s) => (
            <div key={s.label} className="metric-card flex items-center gap-4">
              <div className={`w-12 h-12 ${s.bg} rounded-xl flex items-center justify-center flex-shrink-0`}>
                <s.icon className={`w-6 h-6 ${s.color}`} />
              </div>
              <div>
                <div className="text-xl font-bold text-gray-900 dark:text-white font-['Space_Grotesk']">{s.value}</div>
                <div className="text-xs text-gray-500 dark:text-gray-400">{s.label}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Quick Analyzer */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 lg:py-12">
        <div className="max-w-2xl mx-auto">
          <div className="bg-white dark:bg-gray-900 rounded-3xl shadow-xl border border-gray-100 dark:border-gray-800 p-8 glow-blue">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-cyan-500 rounded-xl flex items-center justify-center">
                <Shield className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-900 dark:text-white font-['Space_Grotesk']">Quick Content Analysis</h2>
                <p className="text-sm text-gray-500 dark:text-gray-400">Powered by Random Forest + TF-IDF</p>
              </div>
            </div>

            <div className="mt-6">
              <textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Enter an Indonesian comment to analyze... (e.g., 'Produk ini sangat bagus!' or a toxic comment)"
                rows={4}
                className="w-full bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl px-4 py-3 text-gray-800 dark:text-gray-200 placeholder-gray-400 dark:placeholder-gray-500 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              />
              <div className="flex items-center justify-between mt-3">
                <span className="text-xs text-gray-400 dark:text-gray-500">{comment.length} characters</span>
                <button
                  onClick={handleAnalyze}
                  disabled={!comment.trim() || loading}
                  className="btn-primary text-sm py-2.5 px-5 flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {loading ? (
                    <>
                      <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                      </svg>
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <Brain className="w-4 h-4" />
                      Analyze Content
                    </>
                  )}
                </button>
              </div>
            </div>

            {result && <ResultCard result={result} />}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 lg:py-16">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white font-['Space_Grotesk']">Research Highlights</h2>
          <p className="text-gray-500 dark:text-gray-400 mt-2">Key aspects of this AI moderation system</p>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {[
            {
              title: 'Random Forest Algorithm',
              desc: 'Ensemble learning method with 100 decision trees for robust toxic comment classification with high accuracy.',
              icon: Brain,
              gradient: 'from-blue-600 to-blue-400',
            },
            {
              title: 'TF-IDF Feature Extraction',
              desc: 'Term Frequency-Inverse Document Frequency converts raw text into numerical feature vectors for ML processing.',
              icon: Zap,
              gradient: 'from-emerald-600 to-emerald-400',
            },
            {
              title: 'Indonesian NLP Pipeline',
              desc: 'Specialized preprocessing for Indonesian language: tokenization, stopword removal, and stemming.',
              icon: Shield,
              gradient: 'from-amber-600 to-amber-400',
            },
          ].map((f) => (
            <div key={f.title} className="bg-white dark:bg-gray-900 rounded-2xl p-6 border border-gray-100 dark:border-gray-800 shadow-sm hover:shadow-md transition-all duration-300 group">
              <div className={`w-12 h-12 bg-gradient-to-br ${f.gradient} rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                <f.icon className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2 font-['Space_Grotesk']">{f.title}</h3>
              <p className="text-gray-500 dark:text-gray-400 text-sm leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
