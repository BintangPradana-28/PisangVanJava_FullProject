import { BookOpen, Target, Lightbulb, Database, Cpu, BarChart3, ChevronDown, ChevronUp } from 'lucide-react';
import { useState } from 'react';

interface SectionProps {
  id: string;
  icon: React.ElementType;
  title: string;
  color: string;
  children: React.ReactNode;
}

function Section({ icon: Icon, title, color, children }: SectionProps) {
  const [open, setOpen] = useState(true);
  return (
    <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800 shadow-sm overflow-hidden">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between p-6 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors"
      >
        <div className="flex items-center gap-3">
          <div className={`w-10 h-10 ${color} rounded-xl flex items-center justify-center`}>
            <Icon className="w-5 h-5" />
          </div>
          <h2 className="text-lg font-bold text-gray-900 dark:text-white font-['Space_Grotesk']">{title}</h2>
        </div>
        {open ? <ChevronUp className="w-5 h-5 text-gray-400" /> : <ChevronDown className="w-5 h-5 text-gray-400" />}
      </button>
      {open && (
        <div className="px-6 pb-6 animate-fade-in">
          <div className="border-t border-gray-100 dark:border-gray-800 pt-5">
            {children}
          </div>
        </div>
      )}
    </div>
  );
}

function Tag({ text, variant = 'blue' }: { text: string; variant?: string }) {
  const variants: Record<string, string> = {
    blue: 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 border-blue-200 dark:border-blue-800',
    emerald: 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800',
    amber: 'bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400 border-amber-200 dark:border-amber-800',
    purple: 'bg-purple-50 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400 border-purple-200 dark:border-purple-800',
    gray: 'bg-gray-50 dark:bg-gray-800 text-gray-600 dark:text-gray-400 border-gray-200 dark:border-gray-700',
  };
  return (
    <span className={`inline-block text-xs font-medium px-2.5 py-1 rounded-lg border ${variants[variant]}`}>{text}</span>
  );
}

function StepCard({ number, title, desc }: { number: string; title: string; desc: string }) {
  return (
    <div className="flex gap-4">
      <div className="flex-shrink-0 w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white text-sm font-bold">
        {number}
      </div>
      <div>
        <div className="font-semibold text-gray-800 dark:text-gray-200 text-sm">{title}</div>
        <div className="text-gray-500 dark:text-gray-400 text-sm mt-0.5 leading-relaxed">{desc}</div>
      </div>
    </div>
  );
}

export default function ResearchPage() {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 pt-20">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-gradient-to-br from-amber-500 to-orange-500 rounded-xl flex items-center justify-center">
              <BookOpen className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white font-['Space_Grotesk']">Research Paper</h1>
              <p className="text-sm text-gray-500 dark:text-gray-400">Academic documentation and methodology</p>
            </div>
          </div>

          {/* Paper title card */}
          <div className="bg-gradient-to-br from-blue-700 to-blue-900 rounded-2xl p-6 text-white relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -translate-y-32 translate-x-32" />
            <div className="relative">
              <div className="text-blue-200 text-sm font-medium mb-2 uppercase tracking-wide">Research Title</div>
              <h2 className="text-xl sm:text-2xl font-bold leading-snug mb-4 font-['Space_Grotesk']">
                AI-Based Content Moderation System for Detecting Toxic Indonesian Comments Using Random Forest
              </h2>
              <div className="flex flex-wrap gap-2">
                <Tag text="Machine Learning" variant="blue" />
                <Tag text="NLP" variant="blue" />
                <Tag text="Content Moderation" variant="blue" />
                <Tag text="Random Forest" variant="blue" />
                <Tag text="Indonesian Language" variant="blue" />
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          {/* Background */}
          <Section id="background" icon={BookOpen} title="Background" color="bg-blue-100 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400">
            <div className="prose dark:prose-invert max-w-none">
              <p className="text-gray-600 dark:text-gray-400 leading-relaxed text-sm">
                The rapid growth of social media platforms has created an urgent need for effective content moderation systems.
                Toxic comments — including hate speech, harassment, and offensive language — pose significant threats to online communities
                and mental health of users. Indonesia, as one of the world's largest social media user bases, faces a unique challenge
                due to the linguistic complexity of the Indonesian language and its regional dialects.
              </p>
              <p className="text-gray-600 dark:text-gray-400 leading-relaxed text-sm mt-3">
                Traditional rule-based moderation systems fail to capture the nuanced and context-dependent nature of toxic
                Indonesian language. Machine learning approaches, particularly ensemble methods, offer promising solutions
                for automated toxic comment detection with high accuracy and scalability.
              </p>
              <div className="grid sm:grid-cols-3 gap-3 mt-4">
                {[
                  { stat: '4.2B+', label: 'Social media users worldwide' },
                  { stat: '70%+', label: 'Report exposure to toxic content' },
                  { stat: '191M', label: 'Indonesian internet users' },
                ].map(s => (
                  <div key={s.label} className="bg-blue-50 dark:bg-blue-900/20 rounded-xl p-3 text-center border border-blue-100 dark:border-blue-800">
                    <div className="text-xl font-bold text-blue-600 dark:text-blue-400 font-['Space_Grotesk']">{s.stat}</div>
                    <div className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{s.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </Section>

          {/* Research Gap */}
          <Section id="gap" icon={Target} title="Research Gap" color="bg-red-100 dark:bg-red-900/20 text-red-600 dark:text-red-400">
            <div className="space-y-3">
              {[
                { problem: 'Language Specificity', desc: 'Existing content moderation systems are predominantly designed for English, performing poorly on Indonesian language with its complex morphology and informal slang.' },
                { problem: 'Dataset Scarcity', desc: 'There is a significant shortage of labeled Indonesian toxic comment datasets, making it difficult to train and evaluate ML models effectively.' },
                { problem: 'Real-Time Processing', desc: 'Most research focuses on offline batch processing rather than real-time web-based systems suitable for production deployment.' },
                { problem: 'Explainability', desc: 'Black-box deep learning models lack interpretability needed for transparent moderation decisions in regulatory compliance.' },
              ].map(g => (
                <div key={g.problem} className="flex gap-3 p-4 bg-red-50 dark:bg-red-900/10 rounded-xl border border-red-100 dark:border-red-800">
                  <div className="w-2 h-2 bg-red-500 rounded-full mt-1.5 flex-shrink-0" />
                  <div>
                    <div className="font-semibold text-red-700 dark:text-red-400 text-sm">{g.problem}</div>
                    <div className="text-gray-600 dark:text-gray-400 text-sm mt-0.5">{g.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </Section>

          {/* Novelty */}
          <Section id="novelty" icon={Lightbulb} title="Novelty & Contribution" color="bg-amber-100 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400">
            <div className="space-y-3">
              {[
                { title: 'Web-Based Real-Time System', desc: 'First Indonesian toxic comment detection system deployed as an interactive web application with real-time classification capability.' },
                { title: 'Optimized RF + TF-IDF Pipeline', desc: 'Novel combination of TF-IDF vectorization with n-gram features (1-3) and Random Forest with tuned hyperparameters specifically for Indonesian toxic language.' },
                { title: 'Comprehensive Evaluation', desc: 'Multi-metric evaluation framework including accuracy, precision, recall, F1-score, and confusion matrix analysis on a balanced Indonesian dataset.' },
                { title: 'Risk-Level Classification', desc: 'Beyond binary classification, the system provides 4-tier risk levels (Low/Medium/High/Critical) with specific moderation action recommendations.' },
              ].map((n, i) => (
                <div key={n.title} className="flex gap-3 p-4 bg-amber-50 dark:bg-amber-900/10 rounded-xl border border-amber-100 dark:border-amber-800">
                  <div className="flex-shrink-0 w-6 h-6 bg-amber-500 rounded-lg flex items-center justify-center text-white text-xs font-bold">
                    {i + 1}
                  </div>
                  <div>
                    <div className="font-semibold text-amber-700 dark:text-amber-400 text-sm">{n.title}</div>
                    <div className="text-gray-600 dark:text-gray-400 text-sm mt-0.5">{n.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </Section>

          {/* Objectives */}
          <Section id="objectives" icon={Target} title="Research Objectives" color="bg-emerald-100 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400">
            <ol className="space-y-3">
              {[
                'To develop a machine learning model using the Random Forest algorithm for classifying toxic comments in Indonesian social media text.',
                'To implement TF-IDF feature extraction with optimized n-gram parameters to convert Indonesian text into numerical feature representations.',
                'To build a real-time web-based AI moderation system that processes user-submitted comments and provides instant toxicity classifications.',
                'To evaluate the developed model using standard classification metrics: accuracy, precision, recall, and F1-score.',
                'To analyze the confusion matrix and per-class performance to understand model strengths and limitations.',
              ].map((obj, i) => (
                <li key={i} className="flex gap-3">
                  <span className="flex-shrink-0 w-6 h-6 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-lg flex items-center justify-center text-sm font-bold border border-emerald-200 dark:border-emerald-800">
                    {i + 1}
                  </span>
                  <span className="text-gray-600 dark:text-gray-400 text-sm leading-relaxed">{obj}</span>
                </li>
              ))}
            </ol>
          </Section>

          {/* Dataset */}
          <Section id="dataset" icon={Database} title="Dataset Information" color="bg-purple-100 dark:bg-purple-900/20 text-purple-600 dark:text-purple-400">
            <div className="grid sm:grid-cols-2 gap-4 mb-4">
              {[
                { label: 'Dataset Name', value: 'Indonesian Toxic Comment Dataset' },
                { label: 'Source', value: 'Twitter & YouTube Comments' },
                { label: 'Total Samples', value: '10,000 comments' },
                { label: 'Language', value: 'Bahasa Indonesia' },
                { label: 'Classes', value: 'Toxic / Non-Toxic (Binary)' },
                { label: 'Collection Period', value: '2022 – 2024' },
              ].map(f => (
                <div key={f.label} className="bg-gray-50 dark:bg-gray-800 rounded-xl p-3">
                  <div className="text-xs text-gray-400 mb-0.5">{f.label}</div>
                  <div className="text-sm font-medium text-gray-800 dark:text-gray-200">{f.value}</div>
                </div>
              ))}
            </div>
            <div className="bg-purple-50 dark:bg-purple-900/10 rounded-xl p-4 border border-purple-100 dark:border-purple-800">
              <h4 className="font-semibold text-purple-700 dark:text-purple-400 text-sm mb-2">Preprocessing Steps Applied</h4>
              <div className="flex flex-wrap gap-2">
                {['Case Normalization', 'URL Removal', 'Punctuation Removal', 'Stopword Removal', 'Tokenization', 'Stemming (Sastrawi)', 'Slang Normalization', 'Emoji Removal'].map(t => (
                  <Tag key={t} text={t} variant="purple" />
                ))}
              </div>
            </div>
          </Section>

          {/* Methodology */}
          <Section id="methodology" icon={Cpu} title="AI Methodology" color="bg-blue-100 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400">
            <div className="space-y-4">
              <div className="space-y-3">
                {[
                  { n: '1', title: 'Data Collection & Annotation', desc: 'Gather Indonesian comments from Twitter and YouTube, then manually annotate as toxic or non-toxic with inter-annotator agreement validation.' },
                  { n: '2', title: 'Text Preprocessing', desc: 'Apply NLP pipeline: lowercase conversion, URL/hashtag removal, tokenization, stopword removal, and Sastrawi stemming for Indonesian morphology.' },
                  { n: '3', title: 'TF-IDF Feature Extraction', desc: 'Convert preprocessed text to TF-IDF vectors with 1-3 n-gram range and maximum 10,000 features to capture term importance in corpus.' },
                  { n: '4', title: 'Random Forest Training', desc: 'Train ensemble model with 100 estimators, max depth 15, class weight balanced, and 5-fold stratified cross-validation.' },
                  { n: '5', title: 'Hyperparameter Tuning', desc: 'Apply GridSearchCV to optimize n_estimators, max_depth, min_samples_split, and min_samples_leaf parameters.' },
                  { n: '6', title: 'Model Evaluation', desc: 'Evaluate on held-out test set using accuracy, precision, recall, F1-score, and analyze confusion matrix for class-level insights.' },
                ].map(s => (
                  <StepCard key={s.n} number={s.n} title={s.title} desc={s.desc} />
                ))}
              </div>
              <div className="bg-blue-50 dark:bg-blue-900/10 rounded-xl p-4 border border-blue-100 dark:border-blue-800 mt-4">
                <h4 className="font-semibold text-blue-700 dark:text-blue-400 text-sm mb-2">Model Hyperparameters</h4>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    ['n_estimators', '100'],
                    ['max_depth', '15'],
                    ['min_samples_split', '5'],
                    ['min_samples_leaf', '2'],
                    ['TF-IDF n-grams', '(1, 3)'],
                    ['Max features', '10,000'],
                  ].map(([k, v]) => (
                    <div key={k} className="bg-white dark:bg-gray-800 rounded-lg p-2.5">
                      <div className="text-xs text-gray-400">{k}</div>
                      <div className="text-sm font-mono font-semibold text-blue-600 dark:text-blue-400">{v}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </Section>

          {/* Evaluation Metrics */}
          <Section id="metrics" icon={BarChart3} title="Evaluation Metrics" color="bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400">
            <div className="grid sm:grid-cols-2 gap-4">
              {[
                { name: 'Accuracy', formula: '(TP + TN) / (TP + TN + FP + FN)', desc: 'Overall proportion of correctly classified comments out of all samples.', value: '94.2%' },
                { name: 'Precision', formula: 'TP / (TP + FP)', desc: 'Fraction of predicted toxic comments that are actually toxic. Minimizes false positives.', value: '93.8%' },
                { name: 'Recall', formula: 'TP / (TP + FN)', desc: 'Fraction of actual toxic comments correctly identified. Minimizes false negatives.', value: '92.5%' },
                { name: 'F1-Score', formula: '2 × (P × R) / (P + R)', desc: 'Harmonic mean of precision and recall, providing balanced metric for imbalanced classes.', value: '93.1%' },
              ].map(m => (
                <div key={m.name} className="bg-gray-50 dark:bg-gray-800 rounded-xl p-4 border border-gray-100 dark:border-gray-700">
                  <div className="flex items-start justify-between mb-2">
                    <span className="font-bold text-gray-800 dark:text-gray-200">{m.name}</span>
                    <span className="text-blue-600 dark:text-blue-400 font-bold text-sm">{m.value}</span>
                  </div>
                  <code className="text-xs bg-white dark:bg-gray-900 px-2 py-1 rounded border border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 block mb-2">{m.formula}</code>
                  <p className="text-xs text-gray-500 dark:text-gray-400">{m.desc}</p>
                </div>
              ))}
            </div>
          </Section>
        </div>
      </div>
    </div>
  );
}
