import { useState } from 'react';
import { Brain, AlertTriangle, CheckCircle, Shield, Info, Loader2 } from 'lucide-react';
import { analyzeComment } from '../utils/mockAnalyzer';
import type { AnalysisResult } from '../utils/mockAnalyzer';

function ConfidenceRing({ value, toxic }: { value: number; toxic: boolean }) {
  const r = 70;
  const circ = 2 * Math.PI * r;
  const filled = circ * (value / 100);
  const color = toxic ? '#ef4444' : '#10b981';

  return (
    <div className="flex flex-col items-center">
      <svg viewBox="0 0 160 160" className="w-40 h-40">
        <circle cx="80" cy="80" r={r} fill="none" stroke="#e5e7eb" strokeWidth="12" className="dark:stroke-gray-700" />
        <circle
          cx="80" cy="80" r={r} fill="none"
          stroke={color} strokeWidth="12"
          strokeDasharray={`${filled} ${circ}`}
          strokeLinecap="round"
          transform="rotate(-90 80 80)"
          style={{ transition: 'stroke-dasharray 1s ease-in-out' }}
        />
        <text x="80" y="72" textAnchor="middle" dominantBaseline="middle" fontSize="28" fontWeight="700" fontFamily="Space Grotesk" className="fill-gray-900 dark:fill-white">
          {value}%
        </text>
        <text x="80" y="96" textAnchor="middle" dominantBaseline="middle" fontSize="11" fontWeight="500" fill={color}>
          CONFIDENCE
        </text>
      </svg>
      <div className={`text-sm font-semibold mt-1 ${toxic ? 'text-red-500' : 'text-emerald-500'}`}>
        {toxic ? 'Toxic' : 'Non-Toxic'}
      </div>
    </div>
  );
}

function CategoryBar({ name, score, toxic }: { name: string; score: number; toxic: boolean }) {
  const color = toxic && score > 50 ? 'bg-red-500' : score > 50 ? 'bg-amber-500' : 'bg-emerald-500';
  return (
    <div>
      <div className="flex justify-between text-sm mb-1">
        <span className="text-gray-600 dark:text-gray-400">{name}</span>
        <span className="font-semibold text-gray-700 dark:text-gray-300">{score}%</span>
      </div>
      <div className="h-2 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden">
        <div
          className={`h-full ${color} rounded-full transition-all duration-700`}
          style={{ width: `${score}%` }}
        />
      </div>
    </div>
  );
}

const EXAMPLE_COMMENTS = [
  { label: 'Non-toxic (Indonesian)', text: 'Produk ini sangat bagus dan membantu sekali, terima kasih!' },
  { label: 'Toxic (Indonesian)', text: 'Orang ini sangat bodoh dan goblok, tidak berguna sama sekali!' },
  { label: 'Non-toxic (English)', text: 'This is an amazing product, I love how helpful and well-designed it is.' },
  { label: 'Toxic (English)', text: 'You stupid idiot, go die in a hole you worthless garbage person!' },
];

export default function ModerationPage() {
  const [text, setText] = useState('');
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [analyzed, setAnalyzed] = useState(false);

  const handleAnalyze = async () => {
    if (!text.trim()) return;
    setLoading(true);
    setResult(null);
    await new Promise(r => setTimeout(r, 1400));
    const res = analyzeComment(text);
    setResult(res);
    setLoading(false);
    setAnalyzed(true);
  };

  const handleExample = (t: string) => {
    setText(t);
    setResult(null);
    setAnalyzed(false);
  };

  const riskColors: Record<string, string> = {
    Low: 'text-emerald-600 bg-emerald-50 dark:text-emerald-400 dark:bg-emerald-900/20 border-emerald-200 dark:border-emerald-800',
    Medium: 'text-amber-600 bg-amber-50 dark:text-amber-400 dark:bg-amber-900/20 border-amber-200 dark:border-amber-800',
    High: 'text-orange-600 bg-orange-50 dark:text-orange-400 dark:bg-orange-900/20 border-orange-200 dark:border-orange-800',
    Critical: 'text-red-600 bg-red-50 dark:text-red-400 dark:bg-red-900/20 border-red-200 dark:border-red-800',
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-cyan-500 rounded-xl flex items-center justify-center">
              <Brain className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white font-['Space_Grotesk']">AI Moderation</h1>
          </div>
          <p className="text-gray-500 dark:text-gray-400 ml-13">
            Real-time toxic content detection using Random Forest classifier with TF-IDF feature extraction
          </p>
        </div>

        <div className="grid lg:grid-cols-5 gap-6">
          {/* Input Panel */}
          <div className="lg:col-span-3 space-y-5">
            <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800 shadow-sm p-6">
              <h2 className="font-semibold text-gray-800 dark:text-white mb-4 flex items-center gap-2">
                <Shield className="w-4 h-4 text-blue-500" />
                Content Input
              </h2>
              <textarea
                value={text}
                onChange={e => setText(e.target.value)}
                placeholder="Enter Indonesian or English text to analyze for toxic content..."
                rows={7}
                className="w-full bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl px-4 py-3 text-sm text-gray-800 dark:text-gray-200 placeholder-gray-400 dark:placeholder-gray-500 resize-none focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              />
              <div className="flex items-center justify-between mt-3">
                <div className="flex items-center gap-2 text-xs text-gray-400">
                  <Info className="w-3.5 h-3.5" />
                  {text.length} / 500 characters
                </div>
                <button
                  onClick={handleAnalyze}
                  disabled={!text.trim() || loading}
                  className="btn-primary text-sm py-2.5 flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {loading ? (
                    <><Loader2 className="w-4 h-4 animate-spin" /> Analyzing...</>
                  ) : (
                    <><Brain className="w-4 h-4" /> Analyze Content</>
                  )}
                </button>
              </div>
            </div>

            {/* Example comments */}
            <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800 shadow-sm p-6">
              <h2 className="font-semibold text-gray-800 dark:text-white mb-4 text-sm">Quick Examples</h2>
              <div className="grid sm:grid-cols-2 gap-2">
                {EXAMPLE_COMMENTS.map((ex) => (
                  <button
                    key={ex.label}
                    onClick={() => handleExample(ex.text)}
                    className="text-left p-3 rounded-xl border border-gray-100 dark:border-gray-700 hover:border-blue-300 dark:hover:border-blue-700 hover:bg-blue-50 dark:hover:bg-blue-900/10 transition-all group"
                  >
                    <div className="text-xs font-medium text-blue-600 dark:text-blue-400 mb-1">{ex.label}</div>
                    <div className="text-xs text-gray-500 dark:text-gray-400 line-clamp-2">{ex.text}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Model info */}
            <div className="bg-gradient-to-br from-blue-600 to-cyan-600 rounded-2xl p-5 text-white">
              <h3 className="font-semibold mb-3">Model Information</h3>
              <div className="grid grid-cols-2 gap-3 text-sm">
                {[
                  ['Algorithm', 'Random Forest'],
                  ['Vectorizer', 'TF-IDF'],
                  ['Estimators', '100 Trees'],
                  ['Max Depth', '15'],
                  ['Language', 'Indonesian + English'],
                  ['Training Set', '8,000 samples'],
                ].map(([k, v]) => (
                  <div key={k} className="bg-white/10 rounded-lg px-3 py-2">
                    <div className="text-white/60 text-xs">{k}</div>
                    <div className="font-medium">{v}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Result Panel */}
          <div className="lg:col-span-2 space-y-5">
            {!result && !loading && (
              <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800 shadow-sm p-8 flex flex-col items-center justify-center text-center h-64">
                <div className="w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-2xl flex items-center justify-center mb-4">
                  <Brain className="w-8 h-8 text-gray-400 dark:text-gray-600" />
                </div>
                <p className="text-gray-500 dark:text-gray-400 text-sm">
                  Enter text and click "Analyze Content" to see AI moderation results
                </p>
              </div>
            )}

            {loading && (
              <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800 shadow-sm p-8 flex flex-col items-center justify-center h-64">
                <Loader2 className="w-10 h-10 text-blue-500 animate-spin mb-4" />
                <p className="text-gray-600 dark:text-gray-400 font-medium">Analyzing content...</p>
                <p className="text-gray-400 dark:text-gray-500 text-xs mt-1">Running TF-IDF + Random Forest</p>
              </div>
            )}

            {result && (
              <div className="space-y-4 animate-scale-in">
                {/* Main result */}
                <div className={`bg-white dark:bg-gray-900 rounded-2xl border-2 shadow-sm p-6 ${result.label === 'toxic' ? 'border-red-200 dark:border-red-800' : 'border-emerald-200 dark:border-emerald-800'}`}>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      {result.label === 'toxic'
                        ? <AlertTriangle className="w-5 h-5 text-red-500" />
                        : <CheckCircle className="w-5 h-5 text-emerald-500" />
                      }
                      <span className="font-bold text-gray-900 dark:text-white">Classification Result</span>
                    </div>
                    <span className={`text-xs font-medium px-3 py-1 rounded-full border ${riskColors[result.riskLevel]}`}>
                      {result.riskLevel} Risk
                    </span>
                  </div>
                  <div className="flex justify-center mb-4">
                    <ConfidenceRing value={result.confidence} toxic={result.label === 'toxic'} />
                  </div>
                  <div className="bg-gray-50 dark:bg-gray-800 rounded-xl p-3 text-sm">
                    <div className="text-gray-500 dark:text-gray-400 text-xs mb-1">Recommended Action</div>
                    <div className="font-medium text-gray-800 dark:text-gray-200">{result.action}</div>
                  </div>
                </div>

                {/* Category breakdown */}
                <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800 shadow-sm p-6">
                  <h3 className="font-semibold text-gray-800 dark:text-white text-sm mb-4">Toxicity Category Scores</h3>
                  <div className="space-y-3">
                    {result.categories.map(cat => (
                      <CategoryBar key={cat.name} name={cat.name} score={cat.score} toxic={result.label === 'toxic'} />
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
