import { Users, GraduationCap, Mail, Github, Linkedin, Brain, Building2, Award } from 'lucide-react';

const TEAM = [
  {
    name: 'Ahmad Fauzan Rizki',
    role: 'Lead Researcher & ML Engineer',
    nim: '2001234567',
    avatar: 'AF',
    bio: 'Specializes in machine learning and natural language processing. Responsible for model architecture, TF-IDF feature engineering, and Random Forest implementation.',
    skills: ['Machine Learning', 'Python', 'NLP', 'Scikit-learn'],
    email: 'ahmad.fauzan@student.utm.ac.id',
    color: 'from-blue-500 to-blue-700',
  },
  {
    name: 'Siti Rahmawati',
    role: 'Data Scientist & Analyst',
    nim: '2001234568',
    avatar: 'SR',
    bio: 'Expert in data collection, preprocessing, and statistical analysis. Led the Indonesian dataset annotation process and managed the research data pipeline.',
    skills: ['Data Analysis', 'Statistics', 'Pandas', 'Data Visualization'],
    email: 'siti.rahmawati@student.utm.ac.id',
    color: 'from-emerald-500 to-emerald-700',
  },
  {
    name: 'Muhammad Rizal',
    role: 'Full-Stack Developer',
    nim: '2001234569',
    avatar: 'MR',
    bio: 'Developed the web-based moderation interface using React and TypeScript. Built the real-time API integration and responsive dashboard design.',
    skills: ['React', 'TypeScript', 'Tailwind CSS', 'REST API'],
    email: 'muhammad.rizal@student.utm.ac.id',
    color: 'from-amber-500 to-orange-600',
  },
  {
    name: 'Nurul Hidayah',
    role: 'Research Writer & Analyst',
    nim: '2001234570',
    avatar: 'NH',
    bio: 'Conducted literature review, research gap analysis, and academic writing. Responsible for documentation, paper formatting, and evaluation methodology.',
    skills: ['Academic Writing', 'Literature Review', 'LaTeX', 'Research Methods'],
    email: 'nurul.hidayah@student.utm.ac.id',
    color: 'from-rose-500 to-pink-600',
  },
];

const SUPERVISORS = [
  {
    name: 'Prof. Dr. Ir. Bambang Santoso, M.T.',
    role: 'Research Supervisor',
    dept: 'Department of Informatics Engineering',
    initial: 'BS',
    color: 'from-gray-600 to-gray-800',
  },
  {
    name: 'Dr. Rina Purwaningrum, S.Kom., M.Cs.',
    role: 'Co-Supervisor',
    dept: 'Department of Informatics Engineering',
    initial: 'RP',
    color: 'from-gray-500 to-gray-700',
  },
];

function MemberCard({ member }: { member: typeof TEAM[0] }) {
  return (
    <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800 shadow-sm overflow-hidden hover:shadow-md transition-all duration-300 group">
      <div className={`h-2 bg-gradient-to-r ${member.color}`} />
      <div className="p-6">
        <div className="flex items-start gap-4 mb-4">
          <div className={`w-14 h-14 bg-gradient-to-br ${member.color} rounded-2xl flex items-center justify-center text-white text-lg font-bold flex-shrink-0 group-hover:scale-105 transition-transform`}>
            {member.avatar}
          </div>
          <div>
            <h3 className="font-bold text-gray-900 dark:text-white font-['Space_Grotesk']">{member.name}</h3>
            <div className="text-sm text-blue-600 dark:text-blue-400 font-medium">{member.role}</div>
            <div className="text-xs text-gray-400 mt-0.5">NIM: {member.nim}</div>
          </div>
        </div>
        <p className="text-sm text-gray-500 dark:text-gray-400 leading-relaxed mb-4">{member.bio}</p>
        <div className="flex flex-wrap gap-1.5 mb-4">
          {member.skills.map(s => (
            <span key={s} className="text-xs bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 px-2 py-0.5 rounded-md">{s}</span>
          ))}
        </div>
        <div className="flex items-center gap-2 text-xs text-gray-400">
          <Mail className="w-3.5 h-3.5" />
          <span className="truncate">{member.email}</span>
        </div>
      </div>
    </div>
  );
}

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {/* Header */}
        <div className="mb-10">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-gradient-to-br from-rose-500 to-pink-600 rounded-xl flex items-center justify-center">
              <Users className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white font-['Space_Grotesk']">About Team</h1>
          </div>
          <p className="text-gray-500 dark:text-gray-400">Meet the researchers behind this project</p>
        </div>

        {/* University card */}
        <div className="bg-gradient-to-br from-blue-800 to-blue-950 rounded-3xl p-8 text-white mb-8 relative overflow-hidden">
          <div className="absolute -top-20 -right-20 w-64 h-64 bg-white/5 rounded-full" />
          <div className="absolute -bottom-20 -left-20 w-64 h-64 bg-white/5 rounded-full" />
          <div className="relative flex flex-col md:flex-row items-start md:items-center gap-6">
            <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center flex-shrink-0">
              <Building2 className="w-9 h-9 text-white" />
            </div>
            <div className="flex-1">
              <div className="text-blue-200 text-sm font-medium mb-1 uppercase tracking-wide">Affiliated Institution</div>
              <h2 className="text-2xl font-bold mb-1 font-['Space_Grotesk']">Universitas Teknologi Indonesia</h2>
              <p className="text-blue-200 text-sm">Faculty of Computer Science · Department of Informatics Engineering</p>
              <div className="flex flex-wrap gap-3 mt-4">
                {[
                  { icon: GraduationCap, text: 'S1 Teknik Informatika' },
                  { icon: Brain, text: 'AI Research Lab' },
                  { icon: Award, text: 'Final Year Project 2024' },
                ].map(item => (
                  <div key={item.text} className="flex items-center gap-1.5 bg-white/10 rounded-lg px-3 py-1.5 text-sm">
                    <item.icon className="w-3.5 h-3.5 text-blue-200" />
                    <span>{item.text}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Project info */}
        <div className="grid sm:grid-cols-3 gap-4 mb-10">
          {[
            { label: 'Project Title', value: 'AI-Based Content Moderation Using Random Forest', color: 'border-l-blue-500' },
            { label: 'Submission Year', value: '2024 / 2025 Academic Year', color: 'border-l-emerald-500' },
            { label: 'Research Category', value: 'Natural Language Processing · Machine Learning', color: 'border-l-amber-500' },
          ].map(p => (
            <div key={p.label} className={`bg-white dark:bg-gray-900 rounded-xl p-4 border border-gray-100 dark:border-gray-800 border-l-4 ${p.color}`}>
              <div className="text-xs text-gray-400 mb-1">{p.label}</div>
              <div className="text-sm font-semibold text-gray-800 dark:text-gray-200">{p.value}</div>
            </div>
          ))}
        </div>

        {/* Team members */}
        <div className="mb-8">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-5 font-['Space_Grotesk'] flex items-center gap-2">
            <Users className="w-5 h-5 text-rose-500" /> Research Team
          </h2>
          <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-5">
            {TEAM.map(m => <MemberCard key={m.name} member={m} />)}
          </div>
        </div>

        {/* Supervisors */}
        <div className="mb-8">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-5 font-['Space_Grotesk'] flex items-center gap-2">
            <GraduationCap className="w-5 h-5 text-blue-500" /> Research Supervisors
          </h2>
          <div className="grid sm:grid-cols-2 gap-4">
            {SUPERVISORS.map(s => (
              <div key={s.name} className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800 shadow-sm p-5 flex items-center gap-4">
                <div className={`w-14 h-14 bg-gradient-to-br ${s.color} rounded-2xl flex items-center justify-center text-white text-base font-bold flex-shrink-0`}>
                  {s.initial}
                </div>
                <div>
                  <h3 className="font-bold text-gray-900 dark:text-white text-sm font-['Space_Grotesk']">{s.name}</h3>
                  <div className="text-xs text-blue-600 dark:text-blue-400 font-medium">{s.role}</div>
                  <div className="text-xs text-gray-400 mt-0.5">{s.dept}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Acknowledgement */}
        <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800 shadow-sm p-6">
          <h2 className="font-bold text-gray-900 dark:text-white mb-3 flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-500" /> Acknowledgement
          </h2>
          <p className="text-gray-500 dark:text-gray-400 text-sm leading-relaxed">
            This research project was conducted as part of the Final Year Project (Tugas Akhir) requirement at the
            Department of Informatics Engineering, Faculty of Computer Science, Universitas Teknologi Indonesia.
            The team would like to express sincere gratitude to our supervisors, Prof. Dr. Ir. Bambang Santoso, M.T.
            and Dr. Rina Purwaningrum, S.Kom., M.Cs., for their invaluable guidance and support throughout this research.
            We also thank the Department of Informatics Engineering for providing the computational resources necessary
            for this project. Special appreciation goes to the open-source community for the libraries and tools that
            made this research possible.
          </p>
        </div>
      </div>
    </div>
  );
}
